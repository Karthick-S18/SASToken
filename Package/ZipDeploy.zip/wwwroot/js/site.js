﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.

var graphendpoint = 'https://graph.microsoft.com';
var kendoGridPageSize = 10;
var sasapp = angular.module('sasapp', ['ngRoute', 'ngSanitize', 'angular-loading-bar', 'kendo.directives']);
function replaceEnterToBreak(str) {
	var val = str.replace(/\r?\n/g, "<br />");
	return val;
}
//Loading Bar Config
sasapp.config(['cfpLoadingBarProvider', function (cfpLoadingBarProvider) {
	cfpLoadingBarProvider.parentSelector = '#bodyContent';
	cfpLoadingBarProvider.includeSpinner = true;

	cfpLoadingBarProvider.spinnerTemplate = '<div style="background-color: #333; opacity: 0.8; position: fixed; left: 0px; top: 0px; z-index: 1000000; height: 100%; width: 100%; overflow: hidden;"><img src="/loader.svg" style="font-size: 50px; z-index: 100000; color: white; position: relative; top: 40%; left: 50%;"/><label style="position: relative; top: 50%; left: 50%; font-size: 50px; color: white;">' + +'</label></div>';
}]);
//Pass data accross Controller
sasapp.factory("StorageService", function () {
	var StorageService = {};
	var storage = [];
	var userDetail = [];
	StorageService.setloggedInUserDetail = function (object) {
		this.userDetail = [];
		this.userDetail = object;
	};
	StorageService.getUserDetail = function () {
		return this.userDetail;
	};
	StorageService.store = function (object) {
		this.storage = [];
		this.storage = object;
	};
	StorageService.getStore = function () {
		return this.storage;
	};
	return StorageService;
});
//Ajax request
sasapp.factory("RequestService", function ($http) {
	var RequestService = {};

	RequestService.GetRequest = function (uri, headersReq) {
		return $http.get(uri, {
			headers: headersReq
		});
	};

	RequestService.PostRequest = function (uri, reqdata) {
		return $http.post(uri, reqdata);
	};

	return RequestService;
});
//Route Config
sasapp.config(function ($routeProvider, $locationProvider) {
	$routeProvider
		.when('/', {
			templateUrl: '/Home/Index'
		})
		.when('/Home', {
			templateUrl: '/Home/Index'
		})
		.when('/Dashboard', {
			templateUrl: '/Home/Dashboard'
		})
		.when('/Storage', {
			templateUrl: '/Home/Storage'
		})
		.when('/ViewStorageAccount', {
			templateUrl: '/Home/ViewStorageAccount'
		})
		.when('/ServiceBus', {
			templateUrl: '/Home/ServiceBus'
		})
		.when('/ViewServiceBus', {
			templateUrl: '/Home/ViewServiceBus'
		})
		.when('/Logs', {
			templateUrl: '/Home/Logs'
		})
		.when('/EmailTemplate', {
			templateUrl: '/Home/EmailTemplate'
		})
		.when('/EventHub', {
			templateUrl: '/Home/EventHub'
		})
		.when('/ViewEventHub', {
			templateUrl: '/Home/ViewEventHub'
		})
		.when('/IoTHub', {
			templateUrl: '/Home/IoTHub'
		})
		.when('/ViewIoTHub', {
			templateUrl: '/Home/ViewIoTHub'
		})
		.when('/Updates', {
			templateUrl: '/Home/Updates'
		})
		.otherwise({
			templateUrl: '/Home/PageNotFound'
		});
	$locationProvider.html5Mode(true);
});

//Landing page
sasapp.controller('homectrl', function ($scope, $location, RequestService, StorageService, cfpLoadingBar) {
	//$location.path('Dashboard');
	$scope.obj = {
		"loggedInUserDetail": "",
		"UserMessage": "ProcessingUserProfile",
		"SubscriptionMessage": "Processing",
		"CredentialsMessage": "ProcessingCredentials",
		"SendGridMessage": "ProcessingSG",
		"WebjobMessage": "ProcessingWebjob"
	};

	$scope.initEmailTemplateCount = 0;
	$scope.initEmailTemplates = ["StorageAccount", "ServiceBus", "EventHubNameSpace", "IoTHub"];

	$scope.provisioningEmailTemplate = function () {

		if ($scope.initEmailTemplates.length > $scope.initEmailTemplateCount) {

			cfpLoadingBar.start();

			var filterBy = $scope.initEmailTemplates[$scope.initEmailTemplateCount];

			var userDetail = StorageService.getUserDetail();
			var reqUrl = "/api/EmailTemplate/ListsByPartitionName?FilterBy=" + filterBy;
			RequestService.GetRequest(reqUrl, {}).then(succ => {
				if (succ.data.length === 0) {
					var reqNewEntryUrl = "/api/EmailTemplate/NewEntry";
					var htmlTemplate = "Hello, <br />SAS Token : {SASToken}";
					var reqdata = {
						"PartitionKey": filterBy,
						'TemplateType': filterBy,
						'Template': htmlTemplate,
						'CreatedBy': userDetail.userName,
						'Subject': 'SAS Token'
					};
					RequestService.PostRequest(reqNewEntryUrl, reqdata).then(succP => {
						console.log(succ);
						$scope.initEmailTemplateCount++;
						$scope.provisioningEmailTemplate();
					}, errP => {
						M.toast({ html: 'Something went wrong!' });
					});

				} else {
					$scope.initEmailTemplateCount++;
					$scope.provisioningEmailTemplate();
				}

			}, err => {
				M.toast({ html: 'Something went wrong!' });
			});

		}
		else {
			cfpLoadingBar.complete();
		}
	};


	$scope.sendGridAPIKeyCheck = function () {
		var userDetail = StorageService.getUserDetail();
		var reqdata = {
			"PartitionKey": "SendGridAPIKey",
			'CreatedBy': userDetail.userName
		};
		RequestService.PostRequest('/api/Validate/CheckSendGridKey', reqdata).then(succ => {
			$scope.obj.SendGridMessage = "Valid";
		}, err => {
			$scope.obj.SendGridMessage = "InValidSG";
			$('.navBarMenu').addClass('addHamBurger');
			//$('.tooltipped').tooltip();
			setTimeout(function () {
				M.AutoInit();
			}, 2000);
		});
	};

	$scope.webjobCheck = function () {

		RequestService.GetRequest('/api/Validate/CheckWebjobs', {}).then(succ => {
			$scope.obj.WebjobMessage = "ValidWebjob";
		}, err => {
			$scope.obj.WebjobMessage = "InValidWebjob";
			$('.navBarMenu').addClass('addHamBurger');
			//$('.tooltipped').tooltip();
			setTimeout(function () {
				M.AutoInit();
			}, 2000);
		});
	};

	var userProfile = window.authContext;
	if (userProfile !== undefined) {
		var user = window.authContext.getCachedUser();
		if (user) {

			$scope.obj.loggedInUserDetail = user.profile.name;
			StorageService.setloggedInUserDetail(user);
			$scope.obj.UserMessage = "ValidUserProfile";

			//Validate SendGrid API Key
			$scope.sendGridAPIKeyCheck();

			//Check Webjob
			$scope.webjobCheck();

			//Provisioning Email Template
			$scope.provisioningEmailTemplate();

			//Validate Azure AD Client id and Client Secret with Tenant id
			var reqHeaders = {
				'tenant': user.profile.tid
			};
			RequestService.GetRequest('/api/Validate/Credentials', reqHeaders).then(succ => {
				$scope.isCredetialsValid = succ.data;
				$scope.obj.CredentialsMessage = "Valid";
				if ($scope.isCredetialsValid === false) {
					$('.navBarMenu').addClass('addHamBurger');
					$scope.obj.CredentialsMessage = "InValid";
					$scope.obj.SubscriptionMessage = "InValid";
				}

				if ($scope.obj.CredentialsMessage === "Valid") {
					RequestService.GetRequest('/api/Validate/Access', reqHeaders).then(succSubsc => {
						$scope.isSubsValid = succSubsc.data;
						$scope.obj.SubscriptionMessage = "Valid";
						if ($scope.isSubsValid === false) {
							$('.navBarMenu').addClass('addHamBurger');
							$scope.obj.SubscriptionMessage = "InValid";
						}
						setTimeout(function () {
							M.AutoInit();
						}, 2000);
					}, errSubsc => {
						$('.navBarMenu').addClass('addHamBurger');
						$scope.obj.SubscriptionMessage = "InValid";
						//$('.tooltipped').tooltip();
						setTimeout(function () {
							M.AutoInit();
						}, 2000);
					});
				}
				//$('.tooltipped').tooltip();
				setTimeout(function () {
					M.AutoInit();
				}, 2000);
			}, err => {
				$('.navBarMenu').addClass('addHamBurger');
				$scope.obj.CredentialsMessage = "InValid";
				$scope.obj.SubscriptionMessage = "InValid";
				//$('.tooltipped').tooltip();
				setTimeout(function () {
					M.AutoInit();
				}, 2000);
			});
		} else {
			$('.navBarMenu').addClass('addHamBurger');
			$scope.obj.UserMessage = "InvalidUserProfile";
			//$('.tooltipped').tooltip();
			setTimeout(function () {
				M.AutoInit();
			}, 2000);
		}

	}

	$scope.navigateDashboard = function () {
		$location.path('Dashboard');
	};

});
//Dashboard
sasapp.controller('dashboardctrl', function ($scope, $location, RequestService, cfpLoadingBar) {

	//Variable Init
	$scope.obj = {
		"LogTotalCount": {},
		"StorageAccount": {},
		"ServiceBus": {},
		"EventHub": {},
		"IoTHub": {},
		"initfilteredDS": "StorageAccount",
		"LogDataFilteredDS": [],
		"GridColumns": [],
		"initFilteredDays": 7
	};

	//Close the side navigation after click on left navigation
	var elem = document.querySelector('.sidenav');
	var instance = M.Sidenav.getInstance(elem);
	instance.close();

	$scope.toolbarOnClick = function (e) {
		$scope.InitFunc(e);
	};

	$scope.InitFunc = function (e) {
		$scope.obj.GridColumns = [];
		var tempds = [];
		$scope.obj.initfilteredDS = e;
		//Set Log Grid Columns Based on Tab Selection
		if (e === "StorageAccount") {
			$scope.obj.GridColumns.push({
				field: "Data.StorageAccount",
				title: "Storage Account",
				width: "200px",
				locked: true,
				lockable: true
			}, {
				field: "serviceType",
				title: "Type",
				width: "120px",
				locked: true,
				lockable: true
			}, {
				field: "startDateTime",
				title: "Start Date Time",
				width: "180px"
			}, {
				field: "endDateTime",
				title: "End Date Time",
				width: "180px"
			}, {
				field: "Data.Permissions",
				title: "Permissions",
				width: "150px"
			}, {
				field: "autoRenewal",
				title: "Auto Renewal",
				width: "100px"
			}, {
				field: "emailId",
				title: "Email Id",
				width: "200px"
			}, {
				field: "Data.CreatedBy",
				title: "Created By",
				width: "180px"
			}, {
				field: "createdOnMoment",
				title: "Created On",
				width: "180px"
			}, {
				field: "autoRenewalDays",
				title: "Auto Renewal Days",
				width: "180px"
			});

			tempds = $scope.obj.StorageAccount.Filter === undefined ? [] : $scope.obj.StorageAccount.Filter;
		}
		else if (e === "ServiceBus") {
			$scope.obj.GridColumns.push({
				field: "Data.ServiceBus",
				title: "Service Bus",
				width: "200px",
				locked: true,
				lockable: true
			}, {
				field: "serviceType",
				title: "Type",
				width: "120px",
				locked: true,
				lockable: true
			}, {
				field: "Data.Queue",
				title: "Queue",
				width: "80px",
				locked: true,
				lockable: true
			}, {
				field: "startDateTime",
				title: "Start Date Time",
				width: "180px"
			}, {
				field: "endDateTime",
				title: "End Date Time",
				width: "180px"
			}, {
				field: "autoRenewal",
				title: "Auto Renewal",
				width: "100px"
			}, {
				field: "emailId",
				title: "Email Id",
				width: "200px"
			}, {
				field: "Data.CreatedBy",
				title: "Created By",
				width: "180px"
			}, {
				field: "createdOnMoment",
				title: "Created On",
				width: "180px"
			}, {
				field: "autoRenewalDays",
				title: "Auto Renewal Days",
				width: "180px"
			});

			tempds = $scope.obj.ServiceBus.Filter === undefined ? [] : $scope.obj.ServiceBus.Filter;

		}
		else if (e === "EventHubNameSpace") {
			$scope.obj.GridColumns.push({
				field: "Data.EventHubNameSpace",
				title: "Namespace",
				width: "200px",
				locked: true,
				lockable: true
			}, {
				field: "Data.EventHub",
				title: "EventHub",
				width: "200px",
				locked: true,
				lockable: true
			}, {
				field: "serviceType",
				title: "Type",
				width: "120px",
				locked: true,
				lockable: true
			}, {
				field: "startDateTime",
				title: "Start Date Time",
				width: "180px"
			}, {
				field: "endDateTime",
				title: "End Date Time",
				width: "180px"
			}, {
				field: "autoRenewal",
				title: "Auto Renewal",
				width: "100px"
			}, {
				field: "emailId",
				title: "Email Id",
				width: "200px"
			}, {
				field: "Data.CreatedBy",
				title: "Created By",
				width: "180px"
			}, {
				field: "createdOnMoment",
				title: "Created On",
				width: "180px"
			}, {
				field: "autoRenewalDays",
				title: "Auto Renewal Days",
				width: "180px"
			});

			tempds = $scope.obj.EventHub.Filter === undefined ? [] : $scope.obj.EventHub.Filter;
		}
		else if (e === "IoTHub") {
			$scope.obj.GridColumns.push({
				field: "Data.IoTHub",
				title: "IoT Hub",
				width: "200px",
				locked: true,
				lockable: true
			}, {
				field: "Data.Device",
				title: "Device",
				width: "200px",
				locked: true,
				lockable: true
			}, {
				field: "serviceType",
				title: "Type",
				width: "120px",
				locked: true,
				lockable: true
			}, {
				field: "startDateTime",
				title: "Start Date Time",
				width: "180px"
			}, {
				field: "endDateTime",
				title: "End Date Time",
				width: "180px"
			}, {
				field: "autoRenewal",
				title: "Auto Renewal",
				width: "100px"
			}, {
				field: "emailId",
				title: "Email Id",
				width: "200px"
			}, {
				field: "Data.CreatedBy",
				title: "Created By",
				width: "180px"
			}, {
				field: "createdOnMoment",
				title: "Created On",
				width: "180px"
			}, {
				field: "autoRenewalDays",
				title: "Auto Renewal Days",
				width: "180px"
			});

			tempds = $scope.obj.IoTHub.Filter === undefined ? [] : $scope.obj.IoTHub.Filter;
		}

		$scope.filteredGridOptions.columns = $scope.obj.GridColumns;
		$scope.obj.LogDataFilteredDS = new kendo.data.DataSource({
			pageSize: kendoGridPageSize,
			transport: {
				read: function (s) {
					s.success(tempds);
				}
			}
		});
	};

	//Init Filterd list grid
	$scope.filteredGridOptions = {
		scrollable: true,
		toolbar: [
			{ template: kendo.template($("#template").html()) }
		],
		height: 450,
		sortable: true,
		pageable: true,
		groupable: true,
		filterable: true
	};

	$scope.filtereddaysOptions = {
		format: "0",
		decimals: 0,
		spinners: false
	};

	$scope.initDashboard = function (days) {
		cfpLoadingBar.start();
		RequestService.GetRequest('/api/Dashboard/Init?FilterByDays=' + days, {}).then(succ => {
			console.log(succ.data);
			var results = succ.data;

			//Total Count
			var obj = {
				"Count": results.logsTotalCount,
				"Field": "TotalCount",
				"Title": "Number of SAS Token",
				"LinkText": "Logs"
			};
			$scope.obj.LogTotalCount = obj;

			$scope.obj.StorageAccount = results.storageAccount;
			$scope.obj.ServiceBus = results.serviceBus;
			$scope.obj.EventHub = results.eventHub;
			$scope.obj.IoTHub = results.ioTHub;

			$scope.MetadataFormatConvert($scope.obj.StorageAccount.Filter);
			$scope.MetadataFormatConvert($scope.obj.ServiceBus.Filter);
			$scope.MetadataFormatConvert($scope.obj.EventHub.Filter);
			$scope.MetadataFormatConvert($scope.obj.IoTHub.Filter);

			//Init Chart
			$scope.initChart(days);

			//Init Storage Account Data
			$scope.InitFunc($scope.obj.initfilteredDS);
			//$scope.filterdGrid.dataSource.read();
			cfpLoadingBar.complete();
		}, err => {
			M.toast({ html: 'Something went wrong!' });
		});

	};

	$scope.initChart = function (days) {
		var ctx = document.getElementById('myChart');
		var firstStack = [$scope.obj.StorageAccount.TotalCount, $scope.obj.ServiceBus.TotalCount, $scope.obj.EventHub.TotalCount, $scope.obj.IoTHub.TotalCount];
		var secondStack = [$scope.obj.StorageAccount.Filter.length, $scope.obj.ServiceBus.Filter.length, $scope.obj.EventHub.Filter.length, $scope.obj.IoTHub.Filter.length];
		var myChart = new Chart(ctx, {
			type: 'bar',
			data: {
				labels: ['Storage Account', 'Service Bus', 'Event Hub', 'IoT Hub'],
				datasets: [{
					label: 'Total Count',
					data: firstStack,
					backgroundColor: "rgba(55, 160, 225, 0.7)"
				}, {
					label: 'Expires in ' + days + ' days',
					data: secondStack,
					backgroundColor: "rgba(225, 58, 55, 0.7)"
				}]
			},
			options: {
				responsive: true,
				maintainAspectRatio: false,
				tooltips: {
					mode: 'label',
					callbacks: {
						label: function (tooltipItem, data) {
							return data.datasets[tooltipItem.datasetIndex].label + ": " + numberWithCommas(tooltipItem.yLabel);
						}
					}
				},
				scales: {
					xAxes: [{
						stacked: true
					}],
					yAxes: [{
						stacked: true
					}]
				}
			}
		});
	};
	var numberWithCommas = function (x) {
		return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
	};
	$scope.MetadataFormatConvert = function (temp) {

		$.each(temp, function (intLog, objLog) {
			var jsonData = JSON.parse(objLog.message);
			objLog["Data"] = jsonData;

			var sdatetime = objLog["startDateTime"];
			objLog["startDateTime"] = moment(sdatetime).format('lll');

			var edatetime = objLog["endDateTime"];
			objLog["endDateTime"] = moment(edatetime).format('lll');

			var createdOn = objLog["createdOn"];
			//objLog["createdOn"] = moment(createdOn).fromNow();
			objLog["createdOnMoment"] = moment(createdOn).fromNow();

		});

	};

	$scope.initDashboard($scope.obj.initFilteredDays);

	//Navigate to Page
	$scope.navigate = function (page) {
		if (page === "TotalCount") {
			$location.path('Logs');
		} else if (page === "StorageAccount") {
			$location.path('Storage');
		} else if (page === "ServiceBus") {
			$location.path('ServiceBus');
		} else if (page === "EventHubNameSpace") {
			$location.path('EventHub');
		} else {
			$location.path('Dashboard');
		}
	};
});
//Logout page
sasapp.controller('logoutctrl', function ($scope) {

});
//Page not found
sasapp.controller('pagenotfoundctrl', function ($scope) {

});

//Storage account list
sasapp.controller('storagectrl', function ($scope, $location, StorageService, cfpLoadingBar) {

	//Variable Init
	$scope.obj = {
		storage: []
	};

	//Close the side navigation after click on left navigation
	var elem = document.querySelector('.sidenav');
	var instance = M.Sidenav.getInstance(elem);
	instance.close();

	//Init Storage account list grid
	$scope.stgaccoptions = {
		scrollable: false,
		sortable: true,
		pageable: true,
		groupable: true,
		filterable: true,
		dataSource: {
			transport: {
				read: function (e) {
					e.success($scope.obj.storage);
				}
			},
			pageSize: kendoGridPageSize
		},
		columns: [{
			command:
				{ text: "Generate SAS Token", click: showDetails },
			title: " ",
			width: "180px"
		}, {
			field: "name",
			title: "Name",
			width: "120px"
		}, {
			field: "resourceGroupName",
			title: "Resource Group Name",
			width: "120px"
		}, {
			field: "region",
			title: "Region",
			width: "120px"
		}]
	};
	function showDetails(e) {
		var dataItem = this.dataItem($(e.currentTarget).closest("tr"));
		StorageService.store(dataItem);
		$location.path('ViewStorageAccount');
	}

	//Get cached user 
	var user = window.authContext.getCachedUser();
	if (!user) {
		M.toast({ html: 'Something went Wrong!!' });
	}
	else {
		window.authContext.acquireToken(graphendpoint, function (error, token) {
			//Get list of Storage accoutnts
			cfpLoadingBar.start();
			$.ajax({
				url: '/api/StorageAccount/Lists',
				headers: { 'tenant': user.profile.tid },
				type: 'GET',
				dataType: 'json',
				success: function (res) {
					$scope.obj.storage = res;
					cfpLoadingBar.complete();
					$scope.stgaccGrid.dataSource.read();
				},
				error: function (err) {
					M.toast({ html: 'Something went wrong!' });
				}
			});
		});
	}

});
//View particular Storage account
sasapp.controller('viewstgaccctrl', function ($scope, StorageService, $location, RequestService) {

	//Get a selected storage account from the Store
	$scope.objStgAcc = StorageService.getStore();
	//Variable Init
	$scope.obj = {
		storageContainers: [],
		folders: [],
		blobs: [],
		currentFolderPath: "",
		containerName: "",
		selectedBlobObj: {},
		type: "Container",
		permission: "",
		startDate: "",
		endDate: "",
		generatedToken: "",
		autoRenewal: false,
		autoRenewalDays: 0,
		autoRenewalEmails: "",
		description: ""
	};

	//Get a selected Storage account details
	if ($scope.objStgAcc.id !== undefined) {
		var reqHeaders = {
			'sas-stgacc': $scope.objStgAcc.name,
			'sas-stgacckey': $scope.objStgAcc.value
		};
		RequestService.GetRequest('/api/StorageAccount/Containers', reqHeaders).then(succ => {
			$scope.obj.storageContainers = succ.data;
		}, err => {
			M.toast({ html: 'Something went wrong!' });
		});
	} else {
		$location.path('ErrorPage');
	}

	//Get Folders and blobs from the selected container
	$scope.getBlobs = function (objBlobs) {
		$scope.obj.currentFolderPath = "";
		var blobReqHeaders = {
			'sas-stgacc': $scope.objStgAcc.name,
			'sas-stgacckey': $scope.objStgAcc.value
		};
		var blobUrl = "/api/StorageAccount/Blobs?container=" + objBlobs.name;
		$scope.obj.containerName = objBlobs.name;
		RequestService.GetRequest(blobUrl, blobReqHeaders).then(succ => {
			$scope.obj.blobs = [];
			$scope.obj.folders = [];
			$scope.obj.blobs = succ.data.blob;
			$scope.obj.folders = succ.data.directory;
			$scope.obj.selectedBlobObj.path = "";
		}, err => {
			M.toast({ html: 'Something went wrong!' });
		});
	};

	//Get Folder and Blobs from the selected Directory
	$scope.getBlobsFromDirectory = function (objDirectory) {
		$scope.obj.currentFolderPath = objDirectory.directoryPath;
		var blobReqHeaders = {
			'sas-stgacc': $scope.objStgAcc.name,
			'sas-stgacckey': $scope.objStgAcc.value
		};
		var blobUrl = "/api/StorageAccount/Blobs?container=" + $scope.obj.containerName + "&folderpath=" + objDirectory.directoryPath;
		RequestService.GetRequest(blobUrl, blobReqHeaders).then(succ => {
			$scope.obj.blobs = [];
			$scope.obj.folders = [];
			$scope.obj.blobs = succ.data.blob;
			$scope.obj.folders = succ.data.directory;
			$scope.obj.selectedBlobObj.path = "";
		}, err => {
			M.toast({ html: 'Something went wrong!' });
		});
	};

	//Folder up
	$scope.folderUp = function () {

		if ($scope.obj.currentFolderPath === "") {
			M.toast({ html: 'No path to move up!' });
		} else {
			var pDirectory = $scope.obj.currentFolderPath;
			var path = "";
			var sp = pDirectory.split('/');
			if (sp.length === 2) {
				path = "";
				$scope.obj.currentFolderPath = "";
			} else if (sp.length === 3) {
				$scope.obj.currentFolderPath = sp[0] + "/";
				path = sp[0] + "/";
			} else {
				var i = sp.slice(0, sp.length - 2);
				$scope.obj.currentFolderPath = i.join('/') + "/";
				path = i.join('/') + "/";
			}

			var blobReqHeaders = {
				'sas-stgacc': $scope.objStgAcc.name,
				'sas-stgacckey': $scope.objStgAcc.value
			};
			var blobUrl = "/api/StorageAccount/Blobs?container=" + $scope.obj.containerName + "&folderpath=" + path;
			RequestService.GetRequest(blobUrl, blobReqHeaders).then(succ => {
				$scope.obj.blobs = [];
				$scope.obj.folders = [];
				$scope.obj.blobs = succ.data.blob;
				$scope.obj.folders = succ.data.directory;
				$scope.obj.selectedBlobObj.path = "";
			}, err => {
				M.toast({ html: 'Something went wrong!' });
			});
		}

	};

	//Selected Blob
	$scope.selectedBlob = function (objBlob) {
		$scope.obj.selectedBlobObj = objBlob;
	};

	//Save Button
	$scope.saveBtn = function () {

		//Permission
		var elem = document.getElementsByClassName('permissions');
		var instance = M.FormSelect.getInstance(elem[0]);
		var permissionSelectedVal = instance.getSelectedValues();
		$scope.obj.permission = permissionSelectedVal.join(', ');

		$scope.stgErrMsg = []; $scope.msg = "";

		if ($scope.obj.type === "Blob" || $scope.obj.type === "Container") {
			if ($scope.obj.containerName === "") {
				$scope.stgErrMsg.push("Container");
			}
		}

		if ($scope.obj.autoRenewal) {
			if ($scope.obj.autoRenewalDays <= 0) {
				$scope.stgErrMsg.push("Should not less than 'Zero'");
			}
		} else {
			$scope.obj.autoRenewalDays = 0;
		}

		$scope.obj.autoRenewalEmails = $("#email").val();
		if ($scope.obj.autoRenewalEmails === "") {
			$scope.stgErrMsg.push("Email Id");
		}
		var isValidEmail = ValidateEmail($scope.obj.autoRenewalEmails);
		if (!isValidEmail) {
			$scope.stgErrMsg.push("Invalid Email Address");
		}
		var userDetail = StorageService.getUserDetail();

		if ($scope.obj.type === "") {
			$scope.stgErrMsg.push("Type");
		}
		if (permissionSelectedVal.length === 0) {
			$scope.stgErrMsg.push("Permission");
		}
		if ($scope.obj.startDate === "") {
			$scope.stgErrMsg.push("Start Date");
		}
		if ($scope.obj.endDate === "") {
			$scope.stgErrMsg.push("End Date");
		}
		if ($scope.obj.description === "") {
			$scope.stgErrMsg.push("Description");
		}
		if ($scope.stgErrMsg.length !== 0) {
			//Validation Failed
			$scope.msg = "Select " + $scope.stgErrMsg.join(', ');
			M.toast({ html: $scope.msg });
		} else {
			//Valid
			if ($scope.obj.selectedBlobObj.path === "" && $scope.obj.type === "Blob") {
				M.toast({ html: 'Select Blob' });
			} else {

				var sd = new Date($scope.obj.startDate);
				var ed = new Date($scope.obj.endDate);
				//Validate start datetime and end datetime
				if (sd < ed) {

					var blobReqHeaders = {
						'sas-stgacc': $scope.objStgAcc.name,
						'sas-stgacckey': $scope.objStgAcc.value,
						'sas-starttime': new Date($scope.obj.startDate).toISOString(),
						'sas-endtime': new Date($scope.obj.endDate).toISOString(),
						'sas-permissions': $scope.obj.permission,
						'sas-emailid': $scope.obj.autoRenewalEmails,
						"sas-createdby": userDetail.userName,
						"sas-description": replaceEnterToBreak($scope.obj.description)
					}, blobUrl = "";
					var SASTokenDetail = {
						"StorageAccount": $scope.objStgAcc.name,
						'Permissions': $scope.obj.permission,
						"CreatedBy": userDetail.userName,
						'Description': replaceEnterToBreak($scope.obj.description)
					};
					if ($scope.obj.type === "Blob" || $scope.obj.type === "Container") {
						if ($scope.obj.type === "Container") {
							blobUrl = "/api/StorageAccount/GenerateSASTokenForContainer?container=" + $scope.obj.containerName;
							SASTokenDetail["Container"] = $scope.obj.containerName;
						} else if ($scope.obj.type === "Blob") {
							SASTokenDetail["Blob"] = $scope.obj.selectedBlobObj.path;
							SASTokenDetail["Container"] = $scope.obj.containerName;
							blobReqHeaders["sas-filepath"] = $scope.obj.selectedBlobObj.path;
							blobUrl = "/api/StorageAccount/GenerateSASTokenForBlob?container=" + $scope.obj.containerName;
						}
					} else if ($scope.obj.type === "Table" || $scope.obj.type === "File" || $scope.obj.type === "Queue") {
						blobUrl = "/api/StorageAccount/GenerateSASToken?servicetype=" + $scope.obj.type;
					}

					RequestService.GetRequest(blobUrl, blobReqHeaders).then(succ => {
						$scope.obj.generatedToken = succ.data;
						M.toast({ html: 'SAS Token Generated!!!' });
						var elem = document.getElementById("savemodal");
						var instance = M.Modal.getInstance(elem);
						instance.open();

						//Log SAS Token and its details

						var reqdata = {
							"PartitionKey": "StorageAccount",
							'StartDateTime': new Date($scope.obj.startDate).toISOString(),
							'EndDateTime': new Date($scope.obj.endDate).toISOString(),
							"ServiceType": $scope.obj.type,
							"Name": $scope.objStgAcc.name,
							"SASToken": $scope.obj.generatedToken,
							"Message": JSON.stringify(SASTokenDetail),
							"AutoRenewal": $scope.obj.autoRenewal,
							"AutoRenewalDays": $scope.obj.autoRenewalDays,
							"EmailId": $scope.obj.autoRenewalEmails
						};
						RequestService.PostRequest('/api/Log/NewEntry', reqdata).then(succ => {
							console.log(succ);
						}, err => {
							M.toast({ html: 'Something went wrong!' });
						});
						//End - Log SAS Token and its details

					}, err => {
						M.toast({ html: 'Something went wrong!' });
					});
				} else if (sd <= ed) {
					M.toast({ html: 'Start datetime and End datetime should not same!' });
				} else {
					M.toast({ html: 'End datetime must be greater than Start datetime!' });
				}

			}
		}

	};

	//Exit Button
	$scope.exitBtn = function () {
		$location.path('Storage');
	};

	//Validate Email
	function ValidateEmail(mail) {
		if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(mail)) {
			return true;
		}
		return false;
	}

});

//Service Bus
sasapp.controller('servicebusctrl', function ($scope, $location, RequestService, StorageService, cfpLoadingBar) {

	//Variable Init
	$scope.obj = {
		servicebus: []
	};

	//Close the side navigation after click on left navigation
	var elem = document.querySelector('.sidenav');
	var instance = M.Sidenav.getInstance(elem);
	instance.close();

	//Init Service bus list grid
	$scope.servicebusoptions = {
		scrollable: false,
		sortable: true,
		pageable: true,
		groupable: true,
		filterable: true,
		dataSource: {
			transport: {
				read: function (e) {
					e.success($scope.obj.servicebus);
				}
			},
			pageSize: kendoGridPageSize
		},
		columns: [{
			command:
				{ text: "Generate SAS Token", click: showDetails },
			title: " ",
			width: "180px"
		}, {
			field: "name",
			title: "Name",
			width: "120px"
		}, {
			field: "resourceGroupName",
			title: "Resource Group Name",
			width: "120px"
		}, {
			field: "region",
			title: "Region",
			width: "120px"
		}]
	};
	function showDetails(e) {
		var dataItem = this.dataItem($(e.currentTarget).closest("tr"));
		StorageService.store(dataItem);
		$location.path('ViewServiceBus');
	}

	//Get cached user
	var user = window.authContext.getCachedUser();
	if (!user) {
		M.toast({ html: 'Something went Wrong!!' });
	}
	else {
		window.authContext.acquireToken(graphendpoint, function (error, token) {
			//Get list of Service bus
			cfpLoadingBar.start();
			var reqHeaders = {
				'tenant': user.profile.tid
			};
			RequestService.GetRequest('/api/ServiceBus/Lists', reqHeaders).then(succ => {
				$scope.obj.servicebus = succ.data;
				cfpLoadingBar.complete();
				$scope.servicebusGrid.dataSource.read();
			}, err => {
				M.toast({ html: 'Something went wrong!' });
			});
		});
	}

});
//View Service Bus
sasapp.controller('viewservicebusctrl', function ($scope, $location, StorageService, RequestService) {
	//Get a selected service bus from the Store
	$scope.objServiceBus = StorageService.getStore();
	//Variable Init
	$scope.obj = {
		"serviceBusQueues": [],
		"serviceBusSAP": [],
		"selectedQueueObj": {},
		"sbgeneratedToken": "",
		"endDate": "",
		"autoRenewal": false,
		"autoRenewalDays": 1,
		//"sasliveinmins": 1,
		"sendtokento": "",
		"description": ""
	};

	//Get a selected service bus details
	if ($scope.objServiceBus.id !== undefined) {
		//Get cached user
		var user = window.authContext.getCachedUser();
		if (!user) {
			M.toast({ html: 'Something went Wrong!!' });
		} else {
			var reqHeaders = {
				'tenant': user.profile.tid,
				'sas-servicebusid': $scope.objServiceBus.id
			};
			RequestService.GetRequest('/api/ServiceBus/Queues', reqHeaders).then(succ => {
				$scope.obj.serviceBusQueues = succ.data;
				/*RequestService.GetRequest('/api/ServiceBus/SharedAccessPolicies', reqHeaders).then(succSAP => {
					$scope.obj.serviceBusSAP = succSAP.data;
				}, err => {
					M.toast({ html: 'Something went wrong!' });
				});*/
			}, err => {
				M.toast({ html: 'Something went wrong!' });
			});
			//
		}
	} else {
		$location.path('ErrorPage');
	}

	//Concate array string with comma separator
	$scope.concatArrayString = function (arr) {
		return arr.join(', ');
	};

	//Selected Queue
	$scope.selectedQueue = function (objQueue) {
		$scope.obj.selectedQueueObj = objQueue;
	};

	//Exit Button
	$scope.exitBtn = function () {
		$location.path('ServiceBus');
	};

	//Validate Email
	function ValidateEmail(mail) {
		if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(mail)) {
			return true;
		}
		return false;
	}

	//Save Button
	$scope.saveBtn = function () {

		$scope.sbErrMsg = []; $scope.msg = "";
		if ($scope.obj.selectedQueueObj.name === undefined) {
			$scope.sbErrMsg.push("Queue");
		}
		/*if ($scope.obj.sasliveinmins <= 0) {
			$scope.sbErrMsg.push("Time to live");
		}*/

		if ($scope.obj.autoRenewal) {
			if ($scope.obj.autoRenewalDays <= 0) {
				$scope.sbErrMsg.push("Should not less than 'Zero'");
			}
		}

		if ($scope.obj.endDate === "") {
			$scope.sbErrMsg.push("End Date");
		}
		if ($scope.obj.description === "") {
			$scope.sbErrMsg.push("Description");
		}

		$scope.obj.sendtokento = $("#email").val();
		if ($scope.obj.sendtokento === "") {
			$scope.sbErrMsg.push("Send SAS token to");
		}
		var isValidEmail = ValidateEmail($scope.obj.sendtokento);
		if (!isValidEmail) {
			$scope.sbErrMsg.push("Invalid Email Address");
		}

		var userDetail = StorageService.getUserDetail();

		if ($scope.sbErrMsg.length !== 0) {
			//Validation Failed
			$scope.msg = "Select " + $scope.sbErrMsg.join(', ');
			M.toast({ html: $scope.msg });
		} else {
			//Valid
			var sbReqHeaders = {
				'sas-servicebusname': $scope.objServiceBus.name,
				'sas-queuename': $scope.obj.selectedQueueObj.name,
				'sas-servicebussaskeyname': 'RootManageSharedAccessKey',
				'sas-servicebussaskey': $scope.objServiceBus.value,
				'sas-enddate': new Date($scope.obj.endDate).toISOString(),
				//'sas-timeToLiveInMinutes': $scope.obj.sasliveinmins,
				"sas-createdby": userDetail.userName,
				"sas-emailid": $scope.obj.sendtokento,
				"sas-description": replaceEnterToBreak($scope.obj.description)
			};
			RequestService.GetRequest('/api/ServiceBus/SASToken', sbReqHeaders).then(succ => {
				$scope.obj.sbgeneratedToken = succ.data.token;
				M.toast({ html: 'SAS Token Generated!!!' });
				var elem = document.getElementById("saveSBmodal");
				var instance = M.Modal.getInstance(elem);
				instance.open();

				//Log SAS Token and its details

				var exDate = new Date();
				var SASTokenDetail = {
					"ServiceBus": $scope.objServiceBus.name,
					'Queue': $scope.obj.selectedQueueObj.name,
					'TimeToLiveInMinutes': succ.data.timetolive,
					"CreatedBy": userDetail.userName,
					"Description": replaceEnterToBreak($scope.obj.description)
				};
				var reqdata = {
					"PartitionKey": "ServiceBus",
					"ServiceType": 'Queue',
					"Name": $scope.objServiceBus.name,
					"SASToken": $scope.obj.sbgeneratedToken,
					'AutoRenewal': $scope.obj.autoRenewal,
					'AutoRenewalDays': $scope.obj.autoRenewalDays,
					"Message": JSON.stringify(SASTokenDetail),
					"EmailId": $scope.obj.sendtokento,
					"EndDateTime": succ.data.enddate
				};
				RequestService.PostRequest('/api/Log/NewEntry', reqdata).then(succ => {
					console.log(succ);
				}, err => {
					M.toast({ html: 'Something went wrong!' });
				});
				//End - Log SAS Token and its details

			}, err => {
				M.toast({ html: 'Something went wrong!' });
			});
		}

	};
});

//Logs
sasapp.controller('logctrl', function ($scope, $location, RequestService) {

	//Variable Init
	$scope.obj = {
		"LogHistoryDS": [],
		"LogHistory": [],
		"GridColumns": [],
		"autorenewalModalData": {}
	};

	//Close the side navigation after click on left navigation
	var elem = document.querySelector('.sidenav');
	var instance = M.Sidenav.getInstance(elem);
	instance.close();

	//Init Toolbar
	$scope.toolbarOptions = {
		items: [
			{
				type: "buttonGroup",
				id: "playerControls",
				buttons: [
					{ id: "StorageAccount", text: "Storage Account", togglable: true, group: "logs", selected: true, toggle: toolbarOnClick },
					{ id: "ServiceBus", text: "Service Bus", togglable: true, group: "logs", toggle: toolbarOnClick },
					{ id: "EventHubNameSpace", text: "Event Hub NameSpace", togglable: true, group: "logs", toggle: toolbarOnClick },
					{ id: "IoTHub", text: "IoT Hub", togglable: true, group: "logs", toggle: toolbarOnClick }
				]
			}
		]
	};

	//Init Storage Account Log list grid
	$scope.logGridOptions = {
		scrollable: true,
		height: 450,
		sortable: true,
		pageable: true,
		groupable: true,
		filterable: true
	};

	//Get all Logs
	$scope.getLogs = function (filterBy) {
		$scope.obj.LogHistory = [];
		$scope.obj.GridColumns = [];
		$scope.obj.GridColumns = [{
			command: [{
				text: "<i class='material-icons'>vpn_key</i>",
				name: "Key",
				title: " ",
				click: openSASTokenModal
			}, {
				text: "<i class='material-icons'>autorenew</i>",
				name: "AutoRenewal",
				title: " ",
				click: openAutoRenewalModal
			}],
			width: "240px",
			locked: true
		}];

		//Set Log Grid Columns Based on Tab Selection
		if (filterBy === "StorageAccount") {
			$scope.obj.GridColumns.push({
				field: "Data.StorageAccount",
				title: "Storage Account",
				width: "200px",
				locked: true,
				lockable: true
			}, {
				field: "serviceType",
				title: "Type",
				width: "120px",
				locked: true,
				lockable: true
			}, {
				field: "startDateTime",
				title: "Start Date Time",
				width: "180px"
			}, {
				field: "endDateTime",
				title: "End Date Time",
				width: "180px"
			}, {
				field: "Data.Permissions",
				title: "Permissions",
				width: "150px"
			}, {
				field: "autoRenewal",
				title: "Auto Renewal",
				width: "100px"
			}, {
				field: "emailId",
				title: "Email Id",
				width: "200px"
			}, {
				field: "Data.CreatedBy",
				title: "Created By",
				width: "180px"
			}, {
				field: "createdOnMoment",
				title: "Created On",
				width: "180px"
			}, {
				field: "autoRenewalDays",
				title: "Auto Renewal Days",
				width: "180px"
			});
		} else if (filterBy === "ServiceBus") {
			$scope.obj.GridColumns.push({
				field: "Data.ServiceBus",
				title: "Service Bus",
				width: "200px",
				locked: true,
				lockable: true
			}, {
				field: "serviceType",
				title: "Type",
				width: "120px",
				locked: true,
				lockable: true
			}, {
				field: "Data.Queue",
				title: "Queue",
				width: "80px",
				locked: true,
				lockable: true
			}, {
				field: "startDateTime",
				title: "Start Date Time",
				width: "180px"
			}, {
				field: "endDateTime",
				title: "End Date Time",
				width: "180px"
			}, {
				field: "autoRenewal",
				title: "Auto Renewal",
				width: "100px"
			}, {
				field: "emailId",
				title: "Email Id",
				width: "200px"
			}, {
				field: "Data.CreatedBy",
				title: "Created By",
				width: "180px"
			}, {
				field: "createdOnMoment",
				title: "Created On",
				width: "180px"
			}, {
				field: "autoRenewalDays",
				title: "Auto Renewal Days",
				width: "180px"
			});
		} else if (filterBy === "EventHubNameSpace") {
			$scope.obj.GridColumns.push({
				field: "Data.EventHubNameSpace",
				title: "Namespace",
				width: "200px",
				locked: true,
				lockable: true
			}, {
				field: "Data.EventHub",
				title: "EventHub",
				width: "200px",
				locked: true,
				lockable: true
			}, {
				field: "serviceType",
				title: "Type",
				width: "120px",
				locked: true,
				lockable: true
			}, {
				field: "startDateTime",
				title: "Start Date Time",
				width: "180px"
			}, {
				field: "endDateTime",
				title: "End Date Time",
				width: "180px"
			}, {
				field: "autoRenewal",
				title: "Auto Renewal",
				width: "100px"
			}, {
				field: "emailId",
				title: "Email Id",
				width: "200px"
			}, {
				field: "Data.CreatedBy",
				title: "Created By",
				width: "180px"
			}, {
				field: "createdOnMoment",
				title: "Created On",
				width: "180px"
			}, {
				field: "autoRenewalDays",
				title: "Auto Renewal Days",
				width: "180px"
			});
		} else if (filterBy === "IoTHub") {
			$scope.obj.GridColumns.push({
				field: "Data.IoTHub",
				title: "Namespace",
				width: "200px",
				locked: true,
				lockable: true
			}, {
				field: "Data.Device",
				title: "EventHub",
				width: "200px",
				locked: true,
				lockable: true
			}, {
				field: "serviceType",
				title: "Type",
				width: "120px",
				locked: true,
				lockable: true
			}, {
				field: "startDateTime",
				title: "Start Date Time",
				width: "180px"
			}, {
				field: "endDateTime",
				title: "End Date Time",
				width: "180px"
			}, {
				field: "autoRenewal",
				title: "Auto Renewal",
				width: "100px"
			}, {
				field: "emailId",
				title: "Email Id",
				width: "200px"
			}, {
				field: "Data.CreatedBy",
				title: "Created By",
				width: "180px"
			}, {
				field: "createdOnMoment",
				title: "Created On",
				width: "180px"
			}, {
				field: "autoRenewalDays",
				title: "Auto Renewal Days",
				width: "180px"
			});
		}
		$scope.logGridOptions.columns = $scope.obj.GridColumns;
		$scope.obj.LogHistoryDS = new kendo.data.DataSource({
			pageSize: kendoGridPageSize,
			transport: {
				read: function (e) {
					e.success($scope.obj.LogHistory);
				}
			}
		});
		//

		var reqUrl = "/api/Log/ListsByPartitionName?FilterBy=" + filterBy;
		RequestService.GetRequest(reqUrl, {}).then(succ => {
			$scope.obj.LogHistory = succ.data;
			$.each($scope.obj.LogHistory, function (intLog, objLog) {
				var jsonData = JSON.parse(objLog.message);
				objLog["Data"] = jsonData;

				var sdatetime = objLog["startDateTime"];
				objLog["startDateTime"] = moment(sdatetime).format('lll');

				var edatetime = objLog["endDateTime"];
				objLog["endDateTime"] = moment(edatetime).format('lll');

				var createdOn = objLog["createdOn"];
				objLog["createdOnMoment"] = moment(createdOn).fromNow();

			});
			$scope.logGrid.dataSource.read();
		}, err => {
			M.toast({ html: 'Something went wrong!' });
		});

	};

	//Open SAS Token Modal popup
	function openSASTokenModal(e) {
		var dataItem = this.dataItem($(e.currentTarget).closest("tr"));
		$("#generatedSASToken").text(dataItem.sasToken);
		M.AutoInit();
		var elem = document.getElementById("logsbottommodal");
		var instance = M.Modal.getInstance(elem);
		instance.open();
	}

	//Open Auto Renewal Modal popup
	function openAutoRenewalModal(e) {
		var dataItem = this.dataItem($(e.currentTarget).closest("tr"));
		$scope.obj.autorenewalModalData = dataItem;
		$scope.$apply();

		M.AutoInit();
		var elem = document.getElementById("autorenewmodal");
		var instance = M.Modal.getInstance(elem);
		instance.open();
	}

	$scope.updateAutoRenewal = function () {

		RequestService.PostRequest('/api/Log/UpdateEntry', $scope.obj.autorenewalModalData).then(succ => {
			console.log(succ);
			var elem = document.getElementById("autorenewmodal");
			var instance = M.Modal.getInstance(elem);
			instance.close();
			M.toast({ html: 'Updated Successfully!' });
		}, err => {
			M.toast({ html: 'Something went wrong!' });
		});

	};

	function toolbarOnClick(e) {
		$scope.getLogs(e.id);
	}

	//Get logs - Init
	$scope.getLogs('StorageAccount');

});

//Email Template
sasapp.controller('emailTemplatectrl', function ($scope, RequestService, StorageService, $location) {

	$scope.obj = {
		html: "",
		type: "StorageAccount",
		emailTemplate: [],
		tools: [],
		subject: ""
	};

	//Close the side navigation after click on left navigation
	var elem = document.querySelector('.sidenav');
	var instance = M.Sidenav.getInstance(elem);
	instance.close();

	//Init Toolbar
	$scope.toolbarOptions = {
		items: [
			{
				type: "buttonGroup",
				id: "playerControls",
				buttons: [
					{ id: "StorageAccount", text: "Storage Account", togglable: true, group: "logs", selected: true, toggle: toolbarOnClick },
					{ id: "ServiceBus", text: "Service Bus", togglable: true, group: "logs", toggle: toolbarOnClick },
					{ id: "EventHubNameSpace", text: "Event Hub", togglable: true, group: "logs", toggle: toolbarOnClick },
					{ id: "IoTHub", text: "Iot Hub", togglable: true, group: "logs", toggle: toolbarOnClick }
				]
			}
		]
	};

	function toolbarOnClick(e) {
		$scope.getEmailTemplate(e.id);
	}

	$scope.getEmailTemplate = function (filterBy) {

		$scope.obj.type = filterBy;

		$scope.obj.tools = ["bold", "italic", "underline", "strikethrough", "justifyLeft", "justifyCenter", "justifyRight", "justifyFull", "insertUnorderedList", "insertOrderedList", "indent", "outdent", "createLink", "unlink", "insertImage", "insertFile", "subscript", "superscript", "tableWizard", "createTable", "addRowAbove", "addRowBelow", "addColumnLeft", "addColumnRight", "deleteRow", "deleteColumn", "mergeCellsHorizontally", "mergeCellsVertically", "splitCellHorizontally", "splitCellVertically", "viewHtml", "formatting", "cleanFormatting", "fontName", "fontSize", "foreColor", "backColor", "print"];
		if (filterBy === "StorageAccount") {
			$scope.obj.tools.push({
				name: "insertHtml",

				items: [
					{ text: "Storage Account Name", value: "{StorageAccountName}" },
					{ text: "Container Name", value: "{ContainerName}" },
					{ text: "Service Type", value: "{ServiceType}" },
					{ text: "Path", value: "{Path}" },
					{ text: "Start Datetime", value: "{StartDateTime}" },
					{ text: "End Datetime", value: "{EndDateTime}" },
					{ text: "Permission", value: "{Permission}" },
					{ text: "SAS Token", value: "{SASToken}" },
					{ text: "Created By", value: "{CreatedBy}" },
					{ text: "Description", value: "{Description}" }
				]
			});
		} else if (filterBy === "ServiceBus") {
			$scope.obj.tools.push({
				name: "insertHtml",
				items: [
					{ text: "Service Bus Name", value: "{ServiceBusName}" },
					{ text: "Queue Name", value: "{QueueName}" },
					{ text: "Service Type", value: "{ServiceType}" },
					{ text: "Time To Live (In Minutes)", value: "{TimeToLiveInMinutes}" },
					{ text: "Start Datetime", value: "{StartDateTime}" },
					{ text: "End Datetime", value: "{EndDateTime}" },
					{ text: "SAS Token", value: "{SASToken}" },
					{ text: "Created By", value: "{CreatedBy}" },
					{ text: "Description", value: "{Description}" }
				]
			});
		} else if (filterBy === "EventHubNameSpace") {
			$scope.obj.tools.push({
				name: "insertHtml",
				items: [
					{ text: "Event Hub Namespace", value: "{EventHubNameSpace}" },
					{ text: "Event Hub", value: "{EventHub}" },
					{ text: "Start Datetime", value: "{StartDateTime}" },
					{ text: "End Datetime", value: "{EndDateTime}" },
					{ text: "SAS Token", value: "{SASToken}" },
					{ text: "Created By", value: "{CreatedBy}" },
					{ text: "Description", value: "{Description}" }
				]
			});
		} else if (filterBy === "IoTHub") {
			$scope.obj.tools.push({
				name: "insertHtml",
				items: [
					{ text: "IoT Hub", value: "{IoTHub}" },
					{ text: "Device", value: "{Device}" },
					{ text: "Start Datetime", value: "{StartDateTime}" },
					{ text: "End Datetime", value: "{EndDateTime}" },
					{ text: "SAS Token", value: "{SASToken}" },
					{ text: "Created By", value: "{CreatedBy}" },
					{ text: "Description", value: "{Description}" }
				]
			});
		}

		$scope.emailTemplateOptions = {
			tools: $scope.obj.tools,
			messages: {
				insertHtml: "Select Field"
			}
		};
		var userDetail = StorageService.getUserDetail();
		var reqUrl = "/api/EmailTemplate/ListsByPartitionName?FilterBy=" + filterBy;
		RequestService.GetRequest(reqUrl, {}).then(succ => {
			$scope.obj.emailTemplate = succ.data;
			if ($scope.obj.emailTemplate.length === 0) {
				var reqNewEntryUrl = "/api/EmailTemplate/NewEntry";
				var htmlTemplate = "Hello, <br />SAS Token : {SASToken}";
				var reqdata = {
					"PartitionKey": filterBy,
					'TemplateType': filterBy,
					'Template': htmlTemplate,
					'CreatedBy': userDetail.userName,
					'Subject': 'SAS Token'
				};
				RequestService.PostRequest(reqNewEntryUrl, reqdata).then(succ => {
					console.log(succ);
					$scope.obj.html = htmlTemplate;
				}, err => {
					M.toast({ html: 'Something went wrong!' });
				});

			} else {
				$scope.obj.html = $scope.obj.emailTemplate[0].template;
				$scope.obj.subject = $scope.obj.emailTemplate[0].subject;
			}

		}, err => {
			M.toast({ html: 'Something went wrong!' });
		});
	};

	$scope.getEmailTemplate($scope.obj.type);

	//Exit Button
	$scope.exitBtn = function () {
		$location.path('Dashboard');
	};

	$scope.saveBtn = function () {

		var userDetail = StorageService.getUserDetail();
		var reqdata = {
			"PartitionKey": $scope.obj.type,
			'Template': $scope.obj.html,
			'ModifiedBy': userDetail.userName,
			'Subject': $scope.obj.subject
		};
		var reqUpdateEntryUrl = "/api/EmailTemplate/UpdateEntry";
		RequestService.PostRequest(reqUpdateEntryUrl, reqdata).then(succ => {
			console.log(succ); M.toast({ html: 'Updated Successfully' });
		}, err => {
			M.toast({ html: 'Something went wrong!' });
		});

	};

});

//Event Hubs
sasapp.controller('eventhubsctrl', function ($scope, RequestService, StorageService, $location, cfpLoadingBar) {

	//Variable Init
	$scope.obj = {
		eventHubNamespaces: []
	};

	//Close the side navigation after click on left navigation
	var elem = document.querySelector('.sidenav');
	var instance = M.Sidenav.getInstance(elem);
	instance.close();

	//Init Event Hub Namespaces list grid
	$scope.eventHubNamespacesoptions = {
		scrollable: false,
		sortable: true,
		pageable: true,
		groupable: true,
		filterable: true,
		dataSource: {
			transport: {
				read: function (e) {
					e.success($scope.obj.eventHubNamespaces);
				}
			},
			pageSize: kendoGridPageSize
		},
		columns: [{
			command:
				{ text: "Generate SAS Token", click: showDetails },
			title: " ",
			width: "180px"
		}, {
			field: "name",
			title: "Name",
			width: "120px"
		}, {
			field: "resourceGroupName",
			title: "Resource Group Name",
			width: "120px"
		}, {
			field: "region",
			title: "Region",
			width: "120px"
		}]
	};
	function showDetails(e) {
		var dataItem = this.dataItem($(e.currentTarget).closest("tr"));
		StorageService.store(dataItem);
		$location.path('ViewEventHub');
	}

	//Get cached user 
	var user = window.authContext.getCachedUser();
	if (!user) {
		M.toast({ html: 'Something went Wrong!!' });
	}
	else {
		window.authContext.acquireToken(graphendpoint, function (error, token) {
			//Get list of Event Hub Namespaces
			cfpLoadingBar.start();
			var reqHeaders = {
				'tenant': user.profile.tid
			};
			RequestService.GetRequest('/api/EventHub/GetAllEventHubNamespaces', reqHeaders).then(succ => {
				$scope.obj.eventHubNamespaces = succ.data;
				cfpLoadingBar.complete();
				$scope.eventHubNamespacesGrid.dataSource.read();
			}, err => {
				M.toast({ html: 'Something went wrong!' });
			});
		});
	}

});
//View Event Hub
sasapp.controller('vieweventhubctrl', function ($scope, $location, StorageService, RequestService) {

	//Get a selected namespace from the Store
	$scope.objEventHubNamespace = StorageService.getStore();

	//Variable Init
	$scope.obj = {
		"eventhubs": [],
		"selectedEventHubObj": {},
		"ehgeneratedToken": "",
		"endDate": "",
		"autoRenewal": false,
		"autoRenewalDays": 1,
		"sendtokento": "",
		"description": ""
	};

	//Get a selected service bus details
	if ($scope.objEventHubNamespace.id !== undefined) {
		//Get cached user
		var user = window.authContext.getCachedUser();
		if (!user) {
			M.toast({ html: 'Something went Wrong!!' });
		} else {
			var reqHeaders = {
				'tenant': user.profile.tid,
				'sas-resourcegroup': $scope.objEventHubNamespace.resourceGroupName,
				'sas-eventhubnamespacename': $scope.objEventHubNamespace.name
			};
			RequestService.GetRequest('/api/EventHub/GetAllEventHubs', reqHeaders).then(succ => {
				$scope.obj.eventhubs = succ.data;
			}, err => {
				M.toast({ html: 'Something went wrong!' });
			});
		}
	} else {
		$location.path('ErrorPage');
	}

	//Concate array string with comma separator
	$scope.concatArrayString = function (arr) {
		return arr.join(', ');
	};

	//Selected Eventhub
	$scope.selectedEventhub = function (objEventhub) {
		$scope.obj.selectedEventHubObj = objEventhub;
	};

	//Exit Button
	$scope.exitBtn = function () {
		$location.path('EventHub');
	};

	//Validate Email
	function ValidateEmail(mail) {
		if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(mail)) {
			return true;
		}
		return false;
	}

	//Save Button
	$scope.saveBtn = function () {

		$scope.ehErrMsg = []; $scope.msg = "";
		if ($scope.obj.selectedEventHubObj.name === undefined) {
			$scope.ehErrMsg.push("Event Hub");
		}

		if ($scope.obj.autoRenewal) {
			if ($scope.obj.autoRenewalDays <= 0) {
				$scope.ehErrMsg.push("Should not less than 'Zero'");
			}
		}

		if ($scope.obj.endDate === "") {
			$scope.ehErrMsg.push("End Date");
		}

		if ($scope.obj.description === "") {
			$scope.ehErrMsg.push("Description");
		}

		$scope.obj.sendtokento = $("#email").val();
		if ($scope.obj.sendtokento === "") {
			$scope.ehErrMsg.push("Send SAS token to");
		}
		var isValidEmail = ValidateEmail($scope.obj.sendtokento);
		if (!isValidEmail) {
			$scope.ehErrMsg.push("Invalid Email Address");
		}

		var userDetail = StorageService.getUserDetail();

		if ($scope.ehErrMsg.length !== 0) {
			//Validation Failed
			$scope.msg = "Select " + $scope.ehErrMsg.join(', ');
			M.toast({ html: $scope.msg });
		} else {
			//Valid

			var ehReqHeaders = {
				'sas-eventhubname': $scope.obj.selectedEventHubObj.name,
				'sas-eventhubnamespacename': $scope.objEventHubNamespace.name,
				'sas-eventhubkeyname': 'RootManageSharedAccessKey',
				'sas-eventhubkey': $scope.objEventHubNamespace.value,
				'sas-enddate': new Date($scope.obj.endDate).toUTCString(),
				//'sas-timeToLiveInMinutes': $scope.obj.sasliveinmins,
				"sas-createdby": userDetail.userName,
				"sas-emailid": $scope.obj.sendtokento,
				"sas-description": replaceEnterToBreak($scope.obj.description)
			};
			RequestService.GetRequest('/api/EventHub/SASToken', ehReqHeaders).then(succ => {
				$scope.obj.ehgeneratedToken = succ.data.token;
				M.toast({ html: 'SAS Token Generated!!!' });
				var elem = document.getElementById("saveEHmodal");
				var instance = M.Modal.getInstance(elem);
				instance.open();

				//Log SAS Token and its details

				var exDate = new Date();
				var SASTokenDetail = {
					"EventHubNameSpace": $scope.objEventHubNamespace.name,
					'EventHub': $scope.obj.selectedEventHubObj.name,
					'TimeToLiveInSeconds': succ.data.timetolive,
					"CreatedBy": userDetail.userName,
					"Description": replaceEnterToBreak($scope.obj.description)
				};
				var reqdata = {
					"PartitionKey": "EventHubNameSpace",
					"ServiceType": 'EventHub',
					"Name": $scope.objEventHubNamespace.name,
					"SASToken": $scope.obj.ehgeneratedToken,
					'AutoRenewal': $scope.obj.autoRenewal,
					'AutoRenewalDays': $scope.obj.autoRenewalDays,
					"Message": JSON.stringify(SASTokenDetail),
					"EmailId": $scope.obj.sendtokento,
					"EndDateTime": succ.data.enddate
				};
				RequestService.PostRequest('/api/Log/NewEntry', reqdata).then(succ => {
					console.log(succ);
				}, err => {
					M.toast({ html: 'Something went wrong!' });
				});
				//End - Log SAS Token and its details

			}, err => {
				M.toast({ html: 'Something went wrong!' });
			});
		}

	};

});

//IoT Hub page
sasapp.controller('iothubctrl', function ($scope, $location, StorageService, RequestService, cfpLoadingBar) {

	//Variable Init
	$scope.obj = {
		iothubs: []
	};

	//Close the side navigation after click on left navigation
	var elem = document.querySelector('.sidenav');
	var instance = M.Sidenav.getInstance(elem);
	instance.close();

	//Init Event Hub Namespaces list grid
	$scope.iothuboptions = {
		scrollable: false,
		sortable: true,
		pageable: true,
		groupable: true,
		filterable: true,
		dataSource: {
			transport: {
				read: function (e) {
					e.success($scope.obj.iothubs);
				}
			},
			pageSize: kendoGridPageSize
		},
		columns: [{
			command:
				{ text: "Generate SAS Token", click: showDetails },
			title: " ",
			width: "180px"
		}, {
			field: "name",
			title: "Name",
			width: "120px"
		}, {
			field: "resourcegroup",
			title: "Resource Group Name",
			width: "120px"
		}, {
			field: "location",
			title: "Region",
			width: "120px"
		}]
	};
	function showDetails(e) {
		var dataItem = this.dataItem($(e.currentTarget).closest("tr"));
		StorageService.store(dataItem);
		$location.path('ViewIoTHub');
	}

	//Get cached user 
	var user = window.authContext.getCachedUser();
	if (!user) {
		M.toast({ html: 'Something went Wrong!!' });
	}
	else {
		window.authContext.acquireToken(graphendpoint, function (error, token) {
			//Get list of Event Hub Namespaces
			cfpLoadingBar.start();
			var reqHeaders = {
				'tenant': user.profile.tid
			};
			RequestService.GetRequest('/api/IoTHub/GetAllIoTHubs', reqHeaders).then(succ => {
				$scope.obj.iothubs = succ.data.value;
				cfpLoadingBar.complete();
				$scope.iothubGrid.dataSource.read();
			}, err => {
				M.toast({ html: 'Something went wrong!' });
			});
		});
	}

});
//View IoT Hub
sasapp.controller('viewiothubctrl', function ($scope, $location, StorageService, RequestService) {

	//Get a selected namespace from the Store
	$scope.objIoTHub = StorageService.getStore();

	//Variable Init
	$scope.obj = {
		devices: [],
		selectedDeviceObj: [],
		"iotgeneratedToken": "",
		"endDate": "",
		"autoRenewal": false,
		"autoRenewalDays": 1,
		"sendtokento": "",
		"description": ""
	};

	//Get a selected service bus details
	if ($scope.objIoTHub.id !== undefined) {
		//Get cached user
		var user = window.authContext.getCachedUser();
		if (!user) {
			M.toast({ html: 'Something went Wrong!!' });
		} else {
			var reqHeaders = {
				'tenant': user.profile.tid,
				'sas-resourcegroup': $scope.objIoTHub.resourcegroup,
				'sas-iothub': $scope.objIoTHub.name
			};
			RequestService.GetRequest('/api/IoTHub/GetAllDevices', reqHeaders).then(succ => {
				$scope.obj.devices = succ.data;
			}, err => {
				M.toast({ html: 'Something went wrong!' });
			});
		}
	} else {
		$location.path('ErrorPage');
	}

	//Selected Device
	$scope.selectedDevice = function (objDevice) {
		$scope.obj.selectedDeviceObj = objDevice;
	};

	//Exit Button
	$scope.exitBtn = function () {
		$location.path('IoTHub');
	};

	//Validate Email
	function ValidateEmail(mail) {
		if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(mail)) {
			return true;
		}
		return false;
	}

	//Save Button
	$scope.saveBtn = function () {

		$scope.iotErrMsg = []; $scope.msg = "";
		if ($scope.obj.selectedDeviceObj.deviceId === undefined) {
			$scope.iotErrMsg.push("Device");
		}

		if ($scope.obj.autoRenewal) {
			if ($scope.obj.autoRenewalDays <= 0) {
				$scope.iotErrMsg.push("Should not less than 'Zero'");
			}
		}

		if ($scope.obj.endDate === "") {
			$scope.iotErrMsg.push("End Date");
		}

		if ($scope.obj.description === "") {
			$scope.iotErrMsg.push("Description");
		}

		$scope.obj.sendtokento = $("#email").val();
		if ($scope.obj.sendtokento === "") {
			$scope.iotErrMsg.push("Send SAS token to");
		}
		var isValidEmail = ValidateEmail($scope.obj.sendtokento);
		if (!isValidEmail) {
			$scope.iotErrMsg.push("Invalid Email Address");
		}

		var userDetail = StorageService.getUserDetail();

		if ($scope.iotErrMsg.length !== 0) {
			//Validation Failed
			$scope.msg = "Select " + $scope.iotErrMsg.join(', ');
			M.toast({ html: $scope.msg });
		} else {
			//Valid

			var ehReqHeaders = {
				'sas-deviceid': $scope.obj.selectedDeviceObj.deviceId,
				'sas-iothub': $scope.objIoTHub.name,
				'sas-resourcegroup': $scope.objIoTHub.resourcegroup,
				'tenant': user.profile.tid,
				'sas-enddate': new Date($scope.obj.endDate).toUTCString(),
				"sas-createdby": userDetail.userName,
				"sas-emailid": $scope.obj.sendtokento,
				"sas-description": replaceEnterToBreak($scope.obj.description)
			};
			RequestService.GetRequest('/api/IoTHub/SASToken', ehReqHeaders).then(succ => {
				$scope.obj.iotgeneratedToken = succ.data.token;
				M.toast({ html: 'SAS Token Generated!!!' });
				var elem = document.getElementById("saveIOTmodal");
				var instance = M.Modal.getInstance(elem);
				instance.open();

				//Log SAS Token and its details

				var exDate = new Date();
				var SASTokenDetail = {
					"IoTHub": $scope.objIoTHub.name,
					'Device': $scope.obj.selectedDeviceObj.deviceId,
					'ResourceGroup': $scope.objIoTHub.resourcegroup,
					'TimeToLiveInSeconds': succ.data.timetolive,
					"CreatedBy": userDetail.userName,
					"Description": replaceEnterToBreak($scope.obj.description)
				};
				var reqdata = {
					"PartitionKey": "IoTHub",
					"ServiceType": 'Device',
					"Name": $scope.objIoTHub.name,
					"SASToken": $scope.obj.iotgeneratedToken,
					'AutoRenewal': $scope.obj.autoRenewal,
					'AutoRenewalDays': $scope.obj.autoRenewalDays,
					"Message": JSON.stringify(SASTokenDetail),
					"EmailId": $scope.obj.sendtokento,
					"EndDateTime": succ.data.enddate
				};
				RequestService.PostRequest('/api/Log/NewEntry', reqdata).then(succ => {
					console.log(succ);
				}, err => {
					M.toast({ html: 'Something went wrong!' });
				});
				//End - Log SAS Token and its details

			}, err => {
				M.toast({ html: 'Something went wrong!' });
			});
		}

	};

});

//Updates page
sasapp.controller('updatesctrl', function ($scope, RequestService) {

	//Variable Init
	$scope.obj = {
		"Updates": []
	};

	RequestService.GetRequest('/api/Updates/AllEntries', {}).then(succ => {
		$scope.obj.Updates = succ.data;
	}, err => {
		M.toast({ html: 'Something went wrong!' });
	});
});