﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.

var graphendpoint = 'https://graph.microsoft.com';
var kendoGridPageSize = 10;
var sasapp = angular.module('sasapp', ['ngRoute', 'angular-loading-bar', 'kendo.directives']);
//Loading Bar Config
sasapp.config(['cfpLoadingBarProvider', function (cfpLoadingBarProvider) {
	cfpLoadingBarProvider.parentSelector = '#bodyContent';
	cfpLoadingBarProvider.includeSpinner = true;

	cfpLoadingBarProvider.spinnerTemplate = '<div style="background-color: #333; opacity: 0.8; position: absolute; left: 0px; top: 0px; z-index: 1000000; height: 100%; width: 100%; overflow: hidden;"><img src="/loader.svg" style="font-size: 50px; z-index: 100000; color: white; position: relative; top: 40%; left: 50%;"/><label style="position: relative; top: 50%; left: 50%; font-size: 50px; color: white;">' + +'</label></div>';
}]);
//Pass data accross Controller
sasapp.factory("StorageService", function () {
	var StorageService = {};
	var storage = [];
	var userDetail = [];
	StorageService.setloggedInUserDetail = function (object) {
		this.userDetail = [];
		this.userDetail = object;
	};
	StorageService.getUserDetail = function () {
		return this.userDetail;
	};
	StorageService.store = function (object) {
		this.storage = [];
		this.storage = object;
	};
	StorageService.getStore = function () {
		return this.storage;
	};
	return StorageService;
});
//Ajax request
sasapp.factory("RequestService", function ($http) {
	var RequestService = {};

	RequestService.GetRequest = function (uri, headersReq) {
		return $http.get(uri, {
			headers: headersReq
		});
	};

	RequestService.PostRequest = function (uri, reqdata) {
		return $http.post(uri, reqdata);
	};

	return RequestService;
});
//Route Config
sasapp.config(function ($routeProvider, $locationProvider) {
	$routeProvider
		.when('/', {
			templateUrl: '/Home/Index',
			controller: 'homectrl'
		})
		.when('/Home', {
			templateUrl: '/Home/Index',
			controller: 'homectrl'
		})
		.when('/Dashboard', {
			templateUrl: '/Home/Dashboard'
		})
		.when('/Storage', {
			templateUrl: '/Home/Storage'
		})
		.when('/ViewStorageAccount', {
			templateUrl: '/Home/ViewStorageAccount'
		})
		.when('/ServiceBus', {
			templateUrl: '/Home/ServiceBus'
		})
		.when('/ViewServiceBus', {
			templateUrl: '/Home/ViewServiceBus'
		})
		.when('/Logs', {
			templateUrl: '/Home/Logs'
		})
		.otherwise({
			templateUrl: '/Home/PageNotFound'
		});
	$locationProvider.html5Mode(true);
});

//Landing page
sasapp.controller('homectrl', function ($scope, $location, RequestService, StorageService) {
	//$location.path('Dashboard');
	$scope.obj = {
		"loggedInUserDetail": "",
		"Subscriptions": [],
		"UserMessage": "ProcessingUserProfile",
		"SubscriptionMessage": "Processing"
	};

	var userProfile = window.authContext;
	if (userProfile !== undefined) {
		var user = window.authContext.getCachedUser();
		if (user) {
			$scope.obj.loggedInUserDetail = user.profile.name;
			StorageService.setloggedInUserDetail(user);
			$scope.obj.UserMessage = "ValidUserProfile";
			//Get all subscriptions
			var reqHeaders = {
				'tenant': user.profile.tid
			};
			RequestService.GetRequest('/api/Subscriptions/Lists', reqHeaders).then(succ => {
				$scope.obj.Subscriptions = succ.data;
				$scope.obj.SubscriptionMessage = "Valid";
				if ($scope.obj.Subscriptions.length === 0) {
					$('.navBarMenu').addClass('addHamBurger');
					$scope.obj.SubscriptionMessage = "InValid";
				}
				//$('.tooltipped').tooltip();
				setTimeout(function () {
					M.AutoInit();
				}, 2000);
			}, err => {
				$('.navBarMenu').addClass('addHamBurger');
				$scope.obj.SubscriptionMessage = "InValid";
				//$('.tooltipped').tooltip();
				setTimeout(function () {
					M.AutoInit();
				}, 2000);
			});
		} else {
			$('.navBarMenu').addClass('addHamBurger');
			$scope.obj.UserMessage = "InvalidUserProfile";
			//$('.tooltipped').tooltip();
			setTimeout(function () {
				M.AutoInit();
			}, 2000);
		}

	}

	$scope.navigateDashboard = function () {
		$location.path('Dashboard');
	};
});
//Dashboard
sasapp.controller('dashboardctrl', function ($scope, $location, RequestService) {

	//Variable Init
	$scope.obj = {
		"InitData": []
	};

	$scope.initDashboard = function(){
		RequestService.GetRequest('/api/Dashboard/Init', {}).then(succ => {
			console.log(succ.data);
			var results = succ.data;
			var tmpData = [];

			//Total Count
			var obj = {
				"Count": results.logsTotalCount,
				"Field": "TotalCount",
				"Title": "Number of SAS Token",
				"LinkText": "Logs"
			};
			tmpData.push(obj);

			//Storage Account
			if (results.services.StorageAccount !== undefined) {
				var objStgAccUd = {
					"Count": results.services.StorageAccount,
					"Field": "StorageAccount",
					"Title": "Storage Account SAS Token",
					"LinkText": "Storage Account"
				};
				tmpData.push(objStgAccUd);
			} else {
				var objStgAcc = {
					"Count": 0,
					"Field": "StorageAccount",
					"Title": "Storage Account SAS Token",
					"LinkText": "Storage Account"
				};
				tmpData.push(objStgAcc);
			}

			//Service bus
			if (results.services.ServiceBus !== undefined) {
				var objServiceBusUd = {
					"Count": results.services.ServiceBus,
					"Field": "ServiceBus",
					"Title": "Service Bus SAS Token",
					"LinkText": "Service Bus"
				};
				tmpData.push(objServiceBusUd);
			} else {
				var objServiceBus = {
					"Count": 0,
					"Field": "ServiceBus",
					"Title": "Service Bus SAS Token",
					"LinkText": "Service Bus"
				};
				tmpData.push(objServiceBus);
			}

			$scope.obj.InitData = tmpData;

		}, err => {
			M.toast({ html: 'Something went wrong!' });
		});

	};

	$scope.initDashboard();

	//Navigate to Page
	$scope.navigate = function (page) {
		if (page === "TotalCount") {
			$location.path('Logs');
		} else if (page === "StorageAccount") {
			$location.path('Storage');
		} else if (page === "ServiceBus") {
			$location.path('ServiceBus');
		} else {
			$location.path('Dashboard');
		}
	};
});
//Logout page
sasapp.controller('logoutctrl', function ($scope) {

});
//Page not found
sasapp.controller('pagenotfoundctrl', function ($scope) {

});

//Storage account list
sasapp.controller('storagectrl', function ($scope, $location, StorageService, cfpLoadingBar) {

	//Variable Init
	$scope.obj = {
		storage: []
	};

	//Init Storage account list grid
	$scope.stgaccoptions = {
		scrollable: false,
		sortable: true,
		pageable: true,
		groupable: true,
		filterable: true,
		dataSource: {
			transport: {
				read: function (e) {
					e.success($scope.obj.storage);
				}
			},
			pageSize: kendoGridPageSize
		},
		columns: [{
			command:
				{ text: "Generate SAS Token", click: showDetails },
			title: " ",
			width: "180px"
		}, {
			field: "name",
			title: "Name",
			width: "120px"
		}, {
			field: "resourceGroupName",
			title: "Resource Group Name",
			width: "120px"
		}, {
			field: "region",
			width: "120px"
		}]
	};
	function showDetails(e) {
		var dataItem = this.dataItem($(e.currentTarget).closest("tr"));
		StorageService.store(dataItem);
		$location.path('ViewStorageAccount');
	}

	//Get cached user 
	var user = window.authContext.getCachedUser();
	if (!user) {
		M.toast({ html: 'Something went Wrong!!' });
	}
	else {
		window.authContext.acquireToken(graphendpoint, function (error, token) {
			//Get list of Storage accoutnts
			cfpLoadingBar.start();
			$.ajax({
				url: '/api/StorageAccount/Lists',
				headers: { 'tenant': user.profile.tid },
				type: 'GET',
				dataType: 'json',
				success: function (res) {
					$scope.obj.storage = res;
					cfpLoadingBar.complete();
					$scope.stgaccGrid.dataSource.read();
				},
				error: function (err) {
					M.toast({ html: 'Something went wrong!' });
				}
			});
		});
	}

});
//View particular Storage account
sasapp.controller('viewstgaccctrl', function ($scope, StorageService, $location, RequestService) {

	//Get a selected storage account from the Store
	$scope.objStgAcc = StorageService.getStore();
	//Variable Init
	$scope.obj = {
		storageContainers: [],
		folders: [],
		blobs: [],
		currentFolderPath: "",
		containerName: "",
		selectedBlobObj: {},
		type: "Container",
		permission: "r",
		startDate: "",
		endDate: "",
		generatedToken: ""
	};

	//Get a selected Storage account details
	if ($scope.objStgAcc.id !== undefined) {
		var reqHeaders = {
			'sas-stgacc': $scope.objStgAcc.name,
			'sas-stgacckey': $scope.objStgAcc.value
		};
		RequestService.GetRequest('/api/StorageAccount/Containers', reqHeaders).then(succ => {
			$scope.obj.storageContainers = succ.data;
		}, err => {
			M.toast({ html: 'Something went wrong!' });
		});
	} else {
		$location.path('ErrorPage');
	}

	//Get Folders and blobs from the selected container
	$scope.getBlobs = function (objBlobs) {
		$scope.obj.currentFolderPath = "";
		var blobReqHeaders = {
			'sas-stgacc': $scope.objStgAcc.name,
			'sas-stgacckey': $scope.objStgAcc.value
		};
		var blobUrl = "/api/StorageAccount/Blobs?container=" + objBlobs.name;
		$scope.obj.containerName = objBlobs.name;
		RequestService.GetRequest(blobUrl, blobReqHeaders).then(succ => {
			$scope.obj.blobs = [];
			$scope.obj.folders = [];
			$scope.obj.blobs = succ.data.blob;
			$scope.obj.folders = succ.data.directory;
			$scope.obj.selectedBlobObj.path = "";
		}, err => {
			M.toast({ html: 'Something went wrong!' });
		});
	};

	//Get Folder and Blobs from the selected Directory
	$scope.getBlobsFromDirectory = function (objDirectory) {
		$scope.obj.currentFolderPath = objDirectory.directoryPath;
		var blobReqHeaders = {
			'sas-stgacc': $scope.objStgAcc.name,
			'sas-stgacckey': $scope.objStgAcc.value
		};
		var blobUrl = "/api/StorageAccount/Blobs?container=" + $scope.obj.containerName + "&folderpath=" + objDirectory.directoryPath;
		RequestService.GetRequest(blobUrl, blobReqHeaders).then(succ => {
			$scope.obj.blobs = [];
			$scope.obj.folders = [];
			$scope.obj.blobs = succ.data.blob;
			$scope.obj.folders = succ.data.directory;
			$scope.obj.selectedBlobObj.path = "";
		}, err => {
			M.toast({ html: 'Something went wrong!' });
		});
	};

	//Folder up
	$scope.folderUp = function () {

		if ($scope.obj.currentFolderPath === "") {
			M.toast({ html: 'No path to move up!' });
		} else {
			var pDirectory = $scope.obj.currentFolderPath;
			var path = "";
			var sp = pDirectory.split('/');
			if (sp.length === 2) {
				path = "";
				$scope.obj.currentFolderPath = "";
			} else if (sp.length === 3) {
				$scope.obj.currentFolderPath = sp[0] + "/";
				path = sp[0] + "/";
			} else {
				var i = sp.slice(0, sp.length - 2);
				$scope.obj.currentFolderPath = i.join('/') + "/";
				path = i.join('/') + "/";
			}

			var blobReqHeaders = {
				'sas-stgacc': $scope.objStgAcc.name,
				'sas-stgacckey': $scope.objStgAcc.value
			};
			var blobUrl = "/api/StorageAccount/Blobs?container=" + $scope.obj.containerName + "&folderpath=" + path;
			RequestService.GetRequest(blobUrl, blobReqHeaders).then(succ => {
				$scope.obj.blobs = [];
				$scope.obj.folders = [];
				$scope.obj.blobs = succ.data.blob;
				$scope.obj.folders = succ.data.directory;
				$scope.obj.selectedBlobObj.path = "";
			}, err => {
				M.toast({ html: 'Something went wrong!' });
			});
		}

	};

	//Selected Blob
	$scope.selectedBlob = function (objBlob) {
		$scope.obj.selectedBlobObj = objBlob;
	};

	//Save Button
	$scope.saveBtn = function () {

		$scope.stgErrMsg = []; $scope.msg = "";

		if ($scope.obj.type === "Blob" || $scope.obj.type === "Container") {
			if ($scope.obj.containerName === "") {
				$scope.stgErrMsg.push("Container");
			}
		}
		if ($scope.obj.type === "") {
			$scope.stgErrMsg.push("Type");
		}
		if ($scope.obj.permission === "") {
			$scope.stgErrMsg.push("Permission");
		}
		if ($scope.obj.startDate === "") {
			$scope.stgErrMsg.push("Start Date");
		}
		if ($scope.obj.endDate === "") {
			$scope.stgErrMsg.push("End Date");
		}

		if ($scope.stgErrMsg.length !== 0) {
			//Validation Failed
			$scope.msg = "Select " + $scope.stgErrMsg.join(', ');
			M.toast({ html: $scope.msg });
		} else {
			//Valid
			if ($scope.obj.selectedBlobObj.path === "" && $scope.obj.type === "Blob") {
				M.toast({ html: 'Select Blob' });
			} else {

				var sd = new Date($scope.obj.startDate);
				var ed = new Date($scope.obj.endDate);
				//Validate start datetime and end datetime
				if (sd < ed) {

					var blobReqHeaders = {
						'sas-stgacc': $scope.objStgAcc.name,
						'sas-stgacckey': $scope.objStgAcc.value,
						'sas-starttime': new Date($scope.obj.startDate).toUTCString(),
						'sas-endtime': new Date($scope.obj.endDate).toUTCString(),
						'sas-permissions': $scope.obj.permission
					}, blobUrl = "";
					if ($scope.obj.type === "Blob" || $scope.obj.type === "Container") {
						if ($scope.obj.type === "Container") {
							blobUrl = "/api/StorageAccount/GenerateSASTokenForContainer?container=" + $scope.obj.containerName;
						} else if ($scope.obj.type === "Blob") {
							blobReqHeaders["sas-filepath"] = $scope.obj.selectedBlobObj.path;
							blobUrl = "/api/StorageAccount/GenerateSASTokenForBlob?container=" + $scope.obj.containerName;
						}
					} else if ($scope.obj.type === "Table" || $scope.obj.type === "File" || $scope.obj.type === "Queue") {
						blobUrl = "/api/StorageAccount/GenerateSASToken?servicetype=" + $scope.obj.type;
					}

					RequestService.GetRequest(blobUrl, blobReqHeaders).then(succ => {
						$scope.obj.generatedToken = succ.data;
						M.toast({ html: 'SAS Token Generated!!!' });
						var elem = document.getElementById("savemodal");
						var instance = M.Modal.getInstance(elem);
						instance.open();

						//Log SAS Token and its details
						var userDetail = StorageService.getUserDetail();
						var SASTokenDetail = {
							"StorageAccount": $scope.objStgAcc.name,
							'StartDateTime': new Date($scope.obj.startDate).toUTCString(),
							'EndDateTime': new Date($scope.obj.endDate).toUTCString(),
							'Permissions': $scope.obj.permission,
							"CreatedBy": userDetail.userName
						};
						var reqdata = {
							"PartitionKey": "StorageAccount",
							"ServiceType": $scope.obj.type,
							"SASToken": $scope.obj.generatedToken,
							"Message": JSON.stringify(SASTokenDetail)
						};
						RequestService.PostRequest('/api/Log/NewEntry', reqdata).then(succ => {
							console.log(succ);
						}, err => {
							M.toast({ html: 'Something went wrong!' });
						});
						//End - Log SAS Token and its details

					}, err => {
						M.toast({ html: 'Something went wrong!' });
					});
				} else if (sd <= ed) {
					M.toast({ html: 'Start datetime and End datetime should not same!' });
				} else {
					M.toast({ html: 'End datetime must be greater than Start datetime!' });
				}

			}
		}

	};

	//Exit Button
	$scope.exitBtn = function () {
		$location.path('Storage');
	};

});

//Service Bus
sasapp.controller('servicebusctrl', function ($scope, $location, RequestService, StorageService, cfpLoadingBar) {

	//Variable Init
	$scope.obj = {
		servicebus: []
	};

	//Init Service bus list grid
	$scope.servicebusoptions = {
		scrollable: false,
		sortable: true,
		pageable: true,
		groupable: true,
		filterable: true,
		dataSource: {
			transport: {
				read: function (e) {
					e.success($scope.obj.servicebus);
				}
			},
			pageSize: kendoGridPageSize
		},
		columns: [{
			command:
				{ text: "Generate SAS Token", click: showDetails },
			title: " ",
			width: "180px"
		}, {
			field: "name",
			title: "Name",
			width: "120px"
		}, {
			field: "resourceGroupName",
			title: "Resource Group Name",
			width: "120px"
		}, {
			field: "region",
			width: "120px"
		}]
	};
	function showDetails(e) {
		var dataItem = this.dataItem($(e.currentTarget).closest("tr"));
		StorageService.store(dataItem);
		$location.path('ViewServiceBus');
	}

	//Get cached user
	var user = window.authContext.getCachedUser();
	if (!user) {
		M.toast({ html: 'Something went Wrong!!' });
	}
	else {
		window.authContext.acquireToken(graphendpoint, function (error, token) {
			//Get list of Service bus
			cfpLoadingBar.start();
			var reqHeaders = {
				'tenant': user.profile.tid
			};
			RequestService.GetRequest('/api/ServiceBus/Lists', reqHeaders).then(succ => {
				$scope.obj.servicebus = succ.data;
				cfpLoadingBar.complete();
				$scope.servicebusGrid.dataSource.read();
			}, err => {
				M.toast({ html: 'Something went wrong!' });
			});
		});
	}

});
//View Service Bus
sasapp.controller('viewservicebusctrl', function ($scope, $location, StorageService, RequestService) {
	//Get a selected service bus from the Store
	$scope.objServiceBus = StorageService.getStore();
	//Variable Init
	$scope.obj = {
		"serviceBusQueues": [],
		"serviceBusSAP": [],
		"selectedQueueObj": {},
		"sbgeneratedToken": "",
		"sasliveinmins": 1
	};

	//Get a selected service bus details
	if ($scope.objServiceBus.id !== undefined) {
		//Get cached user
		var user = window.authContext.getCachedUser();
		if (!user) {
			M.toast({ html: 'Something went Wrong!!' });
		} else {
			var reqHeaders = {
				'tenant': user.profile.tid,
				'sas-servicebusid': $scope.objServiceBus.id
			};
			RequestService.GetRequest('/api/ServiceBus/Queues', reqHeaders).then(succ => {
				$scope.obj.serviceBusQueues = succ.data;
				/*RequestService.GetRequest('/api/ServiceBus/SharedAccessPolicies', reqHeaders).then(succSAP => {
					$scope.obj.serviceBusSAP = succSAP.data;
				}, err => {
					M.toast({ html: 'Something went wrong!' });
				});*/
			}, err => {
				M.toast({ html: 'Something went wrong!' });
			});
			//
		}
	} else {
		$location.path('ErrorPage');
	}

	//Concate array string with comma separator
	$scope.concatArrayString = function (arr) {
		return arr.join(', ');
	};

	//Selected Queue
	$scope.selectedQueue = function (objQueue) {
		$scope.obj.selectedQueueObj = objQueue;
	};

	//Exit Button
	$scope.exitBtn = function () {
		$location.path('ServiceBus');
	};

	//Save Button
	$scope.saveBtn = function () {

		$scope.sbErrMsg = []; $scope.msg = "";
		if ($scope.obj.selectedQueueObj.name === undefined) {
			$scope.sbErrMsg.push("Queue");
		}
		if ($scope.obj.sasliveinmins <= 0) {
			$scope.sbErrMsg.push("Time to live");
		}
		//obj.sasliveinmins

		if ($scope.sbErrMsg.length !== 0) {
			//Validation Failed
			$scope.msg = "Select " + $scope.sbErrMsg.join(', ');
			M.toast({ html: $scope.msg });
		} else {
			//Valid
			var sbReqHeaders = {
				'sas-servicebusname': $scope.objServiceBus.name,
				'sas-queuename': $scope.obj.selectedQueueObj.name,
				'sas-servicebussaskeyname': 'RootManageSharedAccessKey',
				'sas-servicebussaskey': $scope.objServiceBus.value,
				'sas-timeToLiveInMinutes': $scope.obj.sasliveinmins
			};
			RequestService.GetRequest('/api/ServiceBus/SASToken', sbReqHeaders).then(succ => {
				$scope.obj.sbgeneratedToken = succ.data;
				M.toast({ html: 'SAS Token Generated!!!' });
				var elem = document.getElementById("saveSBmodal");
				var instance = M.Modal.getInstance(elem);
				instance.open();

				//Log SAS Token and its details
				var userDetail = StorageService.getUserDetail();
				var SASTokenDetail = {
					"ServiceBus": $scope.objServiceBus.name,
					'Queue': $scope.obj.selectedQueueObj.name,
					'TimeToLiveInMinutes': $scope.obj.sasliveinmins,
					"CreatedBy": userDetail.userName
				};
				var reqdata = {
					"PartitionKey": "ServiceBus",
					"ServiceType": 'Queue',
					"SASToken": $scope.obj.sbgeneratedToken,
					"Message": JSON.stringify(SASTokenDetail)
				};
				RequestService.PostRequest('/api/Log/NewEntry', reqdata).then(succ => {
					console.log(succ);
				}, err => {
					M.toast({ html: 'Something went wrong!' });
				});
				//End - Log SAS Token and its details

			}, err => {
				M.toast({ html: 'Something went wrong!' });
			});
		}

	};
});

//Logs
sasapp.controller('logctrl', function ($scope, $location, RequestService) {

	//Variable Init
	$scope.obj = {
		"LogHistoryDS": [],
		"LogHistory": [],
		"GridColumns": []
	};

	//Init Toolbar
	$scope.toolbarOptions = {
		items: [
			{
				type: "buttonGroup",
				id: "playerControls",
				buttons: [
					{ id: "StorageAccount", text: "Storage Account", togglable: true, group: "logs", selected: true, toggle: toolbarOnClick },
					{ id: "ServiceBus", text: "Service Bus", togglable: true, group: "logs", toggle: toolbarOnClick }
				]
			}
		]
	};

	//Init Storage Account Log list grid
	$scope.logGridOptions = {
		scrollable: false,
		sortable: true,
		pageable: true,
		groupable: true,
		filterable: true
	};

	//Get all Logs
	$scope.getLogs = function (filterBy) {
		$scope.obj.LogHistory = [];
		$scope.obj.GridColumns = [];

		//Set Log Grid Columns Based on Tab Selection
		if (filterBy === "StorageAccount") {
			$scope.obj.GridColumns = [{
				field: "Data.StorageAccount",
				title: "Storage Account"
			}, {
				field: "serviceType",
				title: "Type"
			}, {
				field: "Data.StartDateTime",
				title: "Start Date Time"
			}, {
				field: "Data.EndDateTime",
				title: "End Date Time"
			}, {
				field: "Data.Permissions",
				title: "Permissions"
			}, {
				field: "sasToken",
				title: "SAS Token"
			}, {
				field: "Data.CreatedBy",
				title: "Created By"
			}];
		} else if (filterBy === "ServiceBus") {
			$scope.obj.GridColumns = [{
				field: "Data.ServiceBus",
				title: "Service Bus"
			}, {
				field: "serviceType",
				title: "Type"
			}, {
				field: "Data.Queue",
				title: "Queue"
			}, {
				field: "Data.TimeToLiveInMinutes",
				title: "Time To Live(In Minutes)"
			}, {
				field: "sasToken",
				title: "SAS Token"
			}, {
				field: "Data.CreatedBy",
				title: "Created By"
			}];
		}
		$scope.logGridOptions.columns = $scope.obj.GridColumns;
		$scope.obj.LogHistoryDS = new kendo.data.DataSource({
			pageSize: 500,
			transport: {
				read: function (e) {
					e.success($scope.obj.LogHistory);
				}
			}
		});
		//

		var reqUrl = "/api/Log/ListsByPartitionName?FilterBy=" + filterBy;
		RequestService.GetRequest(reqUrl, {}).then(succ => {
			$scope.obj.LogHistory = succ.data;
			$.each($scope.obj.LogHistory, function (intLog, objLog) {
				var jsonData = JSON.parse(objLog.message);
				objLog["Data"] = jsonData;
			});
			$scope.logGrid.dataSource.read();
		}, err => {
			M.toast({ html: 'Something went wrong!' });
		});

	};

	function toolbarOnClick(e) {
		$scope.getLogs(e.id);
	}
	//Get logs - Init
	$scope.getLogs('StorageAccount');

});